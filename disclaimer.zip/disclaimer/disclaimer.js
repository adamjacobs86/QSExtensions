define([
  "qlik",
  "jquery",
  'underscore',
  "text!./scoped-bootstrap.css",
  // "text!./my-extension.css",
  "text!./disclaimer.html"
], function(qlik,$,_,bootstrap,disclaimer) {

  'use strict';
  $('<style>').html(bootstrap).appendTo('head');
  // $('<style>').html(cssContent).appendTo('head');
  $( '<div>' ).html( disclaimer ).appendTo( 'body' );
  $( '<script src="https://use.fontawesome.com/102c85f77c.js"></script>' ).appendTo( 'body' );
  $( '<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">' ).appendTo( 'body' ); // Bootstrap.js CDN

  var me = {
	initialProperties : {
	  qListObjectDef : {
		qShowAlternatives : true,
		qFrequencyMode : "N",
		qSortCriterias : {
		  qSortByState : 0,
		  qSortByAscii: 1
		},
		qInitialDataFetch : [{
		  qWidth : 1,
		  qHeight : 10000
		}]
	  }
	},
	definition : {
	  type : "items",
	  component : "accordion",
	  items : {
		dimension : {
		  type : "items",
		  label : "Dimensions",
		  ref : "qListObjectDef",
		  min : 1,
		  max : 1,
		  items : {
			label : {
			  type : "string",
			  ref : "qListObjectDef.qDef.qFieldLabels.0",
			  label : "Label",
			  show : true
			},
			libraryId : {
			  type : "string",
			  component : "library-item",
			  libraryItemType : "dimension",
			  ref : "qListObjectDef.qLibraryId",
			  label : "Dimension",
			  show : function(data) {
				return data.qListObjectDef && data.qListObjectDef.qLibraryId;
			  }
			},
			field : {
			  type : "string",
			  expression : "always",
			  expressionType : "dimension",
			  ref : "qListObjectDef.qDef.qFieldDefs.0",
			  label : "Field",
			  show : function(data) {
				return data.qListObjectDef && !data.qListObjectDef.qLibraryId;
			  }
			},
			qSortByAscii:{
			  type: "numeric",
			  component : "dropdown",
			  label : "Sort by Alphabetical",
			  ref : "qListObjectDef.qDef.qSortCriterias.0.qSortByAscii",
			  options : [{
				value : 1,
				label : "Ascending"
			  }, {
				value : 0,
				label : "No"
			  }, {
				value : -1,
				label : "Descending"
			  }],
			  defaultValue : 1,							
			}
		  }
		},
		settings : {
			uses : "settings",
			items : {
				disclaimer : {
			  	ref : "disclaimer",
			  	label : "Disclaimer Variable",
			  	type: "string",
			  	expression: "always"
				},
			}
	  	}
	  }
	},
	snapshot : {
	  canTakeSnapshot : true
	},
	param: {
	  isearch : "",
	  paint : true,
	  maxRows : 100,
	  maxDefaultRows: 100,
	  offset : 0,
	  matches : 0,
	  first : true,
	  render : false,
	  selected : 0,
	  typing : false,
	  disclaimer_first: false
	}
  };

  me.app = qlik.currApp(this);
  
  me.paint = function($element, layout) {
	var self = this, html = "", list1 = "", list2 = "", lastrow = 0, i = 0, count = 0, divmain_v = "", 
		nb_navlist = "", sheets = [], truncateVal = 0, currSheetId = "", searchSheetId = "",
		numSelected=0, qSelected = "",
		lindex = -1, re = "", clearFlag = 0, offset = 0, disclaimerFlag = false, btnHdrColor = "", myid = layout.qInfo.qId;


      //initialize stuff here if needed ...
      

      //set the disclaimer buttons
      // this code sets the buttons to be Accept and Cancel if it's the first time the disclaimer is displayed,
      // if not the first time, (meaning user has already accepted the disclaimer before), only shows the cancel button
	$('.fpd-disclaimer-buttons').empty(); 	//clean it first
	if (!me.param.disclaimer_first) {
		var discb = '<button id="disc-accept" type="button" class="btn btn-default" data-dismiss="modal">Accept</button>';
			discb += '<button id="disc-donotaccept" type="button" class="btn btn-default" data-dismiss="modal">Do Not Accept</button>'
		$('.fpd-disclaimer-buttons').html(discb);
		$("#disc-accept").click(function () {
			$('.strapcl').remove();
			me.app.variable.setNumValue('vDisclaimer',1).then (function () {
				me.param.disclaimer_first = true;
				self.paint($element, layout);
			});
		});
		
		$("#disc-donotaccept").click(function() {
			var topurl = 'here enter a redirect URL if desired to take user if they do not accept the disclaimer';
			$('.strapcl').remove();
			location.replace(topurl);
		});

	} else {
		var discb = '<button id="disc-cancel" type="button" class="btn btn-default" data-dismiss="modal">Close</button>';
		$('.fpd-disclaimer-buttons').html(discb);
		$("#disc-cancel").click(function() {
			$('.strapcl').remove();
		});
	}


	

	this.backendApi.eachDataRow(function(rownum, row) {	
	    // here goes your eachDataRow code
	});


      // get all data
      if (this.backendApi.getRowCount() > lastrow + 1) {
	  var requestPage = [{
		qTop: lastrow+1,
		qLeft: 0,
		qWidth: 1,
		qHeight: Math.min( 10000, this.backendApi.getRowCount() - lastrow )
	  }];
	  self.backendApi.getData( requestPage ).then( function ( dataPages ) {
		self.paint( $element, layout);
	  } );
	}
	

      // here add the scoped bootstrap class 
      var $bootstrapStyle = $( '#' + myid );
      $bootstrapStyle = $( document.createElement( 'div' ) ).attr( 'id', myid ).addClass( 'bootstrap_inside' );
      
      //build your html
      html = "my page here ....";
      //add this if you want a link to the disclaimer
      html += '<li><a id="nb-disclaimer" href="#" title="View and accept the disclaimer">Disclaimer</a></li>';


      $bootstrapStyle.html( html );
      $element.html($bootstrapStyle);
	  

      $(function() {

	  // here add my jquery event handlers

	  // this is the handler for the disclaimer link
	  $("#nb-disclaimer").click(function(e) {
	      e.preventDefault();
	      $( '<link rel="stylesheet" class="strapcl" id="strap" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">' ).appendTo( 'head' ); 
	      $( '#modalDisclaimer' ).modal();
	  });
		
		

	  // the disclaimer is activated here if the variable layout.disclaimer is not set and the parameter disclaimer_first is also not set
	  // 
	  if (layout.disclaimer == '0' && !me.param.disclaimer_first) {
	      $( '<link rel="stylesheet" class="strapcl" id="strap" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">' ).appendTo( 'head' ); 
	      setTimeout(function(){
		  $( '#modalDisclaimer' ).modal();
	      }, 1000);
	  }
      });
      
    
  }

  return me;
});
